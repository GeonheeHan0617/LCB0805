package com.lcb404.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.lcb404.service.StoreService;

@Controller
@RequestMapping("storemenu")
public class StoreController {


	@Autowired  //Autowired는 타입을 이용해서 의존하는 객체를 삽입해 주는 역활을 한다
	@Qualifier("storeService")
	private StoreService storeService;
	 
	
	@RequestMapping("/store")
	public String store() {
		return "storemenu/store";
	}


	
	@RequestMapping("/storeDetail1")
	public String storeDetail1(@RequestParam("POPCORN_CODE") int POPCORN_CODE, Model model) {
		
		model.addAttribute("POPCORN_CODE",POPCORN_CODE);
				
		return "storemenu/storeDtail1";
		
	}
	@RequestMapping("/storeDetail2")
	public String storeDetail2(@RequestParam("POPCORN_CODE") int POPCORN_CODE, Model model) {
		
		model.addAttribute("POPCORN_CODE",POPCORN_CODE);
				
		return "storemenu/storeDtail2";
		
	}
	@RequestMapping("/storeDetail3")
	public String storeDetail3(@RequestParam("POPCORN_CODE") int POPCORN_CODE, Model model) {
		
		model.addAttribute("POPCORN_CODE",POPCORN_CODE);
				
		return "storemenu/storeDtail3";
		
	}
	@RequestMapping("/storeDetail4")
	public String storeDetail4(@RequestParam("POPCORN_CODE") int POPCORN_CODE, Model model) {
		
		model.addAttribute("POPCORN_CODE",POPCORN_CODE);
				
		return "storemenu/storeDtail4";
		
	}
	@RequestMapping("/storeDetail5")
	public String storeDetail5(@RequestParam("POPCORN_CODE") int POPCORN_CODE, Model model) {
		
		model.addAttribute("POPCORN_CODE",POPCORN_CODE);
				
		return "storemenu/storeDtail5";
		
	}
	@RequestMapping("/storeDetail6")
	public String storeDetail6(@RequestParam("POPCORN_CODE") int POPCORN_CODE, Model model) {
		
		model.addAttribute("POPCORN_CODE",POPCORN_CODE);
				
		return "storemenu/storeDtail6";
		
	}
	@RequestMapping("/storeDetail7")
	public String storeDetail7(@RequestParam("POPCORN_CODE") int POPCORN_CODE, Model model) {
		
		model.addAttribute("POPCORN_CODE",POPCORN_CODE);
				
		return "storemenu/storeDtail7";
		
	}
	@RequestMapping("/storeDetail8")
	public String storeDetail8(@RequestParam("POPCORN_CODE") int POPCORN_CODE, Model model) {
		
		model.addAttribute("POPCORN_CODE",POPCORN_CODE);
				
		return "storemenu/storeDtail8";
		
	}
	@RequestMapping("/storeDetail9")
	public String storeDetail9(@RequestParam("POPCORN_CODE") int POPCORN_CODE, Model model) {
		
		model.addAttribute("POPCORN_CODE",POPCORN_CODE);
				
		return "storemenu/storeDtail9";
		
	}

}
