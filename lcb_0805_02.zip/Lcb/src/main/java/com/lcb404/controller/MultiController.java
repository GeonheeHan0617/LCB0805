package com.lcb404.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
@Controller
@RequestMapping("multi")
public class MultiController {

	@RequestMapping("multi")
	public String Multi() {
		
		
		return "multi/multi";
		// TODO Auto-generated constructor stub
	}

}
