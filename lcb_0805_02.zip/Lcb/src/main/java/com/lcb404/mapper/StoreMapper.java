package com.lcb404.mapper;


public interface StoreMapper {
	public int storeDetail1(int POPCORN_CODE);
}
