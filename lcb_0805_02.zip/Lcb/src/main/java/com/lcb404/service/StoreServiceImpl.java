package com.lcb404.service;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.lcb404.mapper.StoreMapper;



@Service("storeService")
public class StoreServiceImpl implements StoreService  {

	@Autowired
	private StoreMapper storeMapper;

	@Override
	public int storeDetail1(int POPCORN_CODE) {
		
		return storeMapper.storeDetail1(POPCORN_CODE);
	}



	


		
	

	
}
