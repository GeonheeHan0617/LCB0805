package com.lcb404.service;




public interface StoreService {
	public int storeDetail1(int POPCORN_CODE);
}
