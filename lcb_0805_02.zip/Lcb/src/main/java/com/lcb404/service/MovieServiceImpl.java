package com.lcb404.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lcb404.command.MovieVO;

import com.lcb404.mapper.MovieMapper;
@Service("movieService")
public class MovieServiceImpl implements MovieService{

	@Autowired
	private MovieMapper movieMapper;
	
//	@Autowired
//	private LikesMapper likesMapper;
	
	@Override
	public MovieVO getList(int MOVIE_CODE) {
		// TODO Auto-generated method stub
		return movieMapper.getList(MOVIE_CODE);
	}

//	@Override
//	public int movieLike(MovieVO vo,String MEMBERS_ID) {
//		// TODO Auto-generated method stub
//		return likesMapper.movieLike(vo,MEMBERS_ID);
//	}
	
}
